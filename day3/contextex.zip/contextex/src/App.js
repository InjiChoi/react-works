import "./App.css";
import Component1 from "./Component1";
import ContextEx1 from "./ContextEx1";

function App() {
  return (
    <div className="App">
      {/* <Component1 /> */}
      <ContextEx1 />
    </div>
  );
}

export default App;
