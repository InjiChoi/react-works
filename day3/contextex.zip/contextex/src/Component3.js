function Component3({ user }) {
  return (
    <div>
      <h1>Component3</h1>
      <h2>{`Hello ${user} again!`}</h2>
    </div>
  );
}

export default Component3;
