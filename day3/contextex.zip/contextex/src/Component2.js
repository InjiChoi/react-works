import Component3 from "./Component3";

function Component2({user}) {
  return (
    <div>
      <h2>Component2</h2>
      <Component3 user={user}/>
    </div>
  );
}

export default Component2;
