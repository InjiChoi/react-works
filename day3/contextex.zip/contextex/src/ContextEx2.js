import ContextEx3 from "./ContextEx3";

function ContextEx2(){
    return (
        <div>
        <h2>ContextEx2</h2>
        <ContextEx3/>
      </div>
    ) 
}
export default ContextEx2;