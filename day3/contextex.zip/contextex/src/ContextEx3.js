import { useState, useContext } from "react";
import { UserContext } from "./ContextEx1";

function ContextEx3() {
  const [myUser, setMyUser] = useState("");
  const context = useContext(UserContext);
  return (
    <div>
      <h2>ContextEx3</h2>
      <h3>{`Hello ${context.user} again!`}</h3>
      <input
        type="text"
        value={myUser}
        onChange={(e) => {
          setMyUser(e.target.value);
        }}
      />
      <button onClick={()=> {context.setUser(myUser)}}>변경</button>
    </div>
  );
}

export default ContextEx3;
