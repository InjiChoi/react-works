import { memo } from "react";

// component의 prop이 변경되지 않으면 component를 렌더링하지 않는다.
const Todos = ({ todos }) => {
  console.log("Todos rendered");
  return (
    <div>
      <h1>My Todos</h1>
      {todos.map((todo, index) => {
        return <p key={index}>{todo}</p>;
      })}
    </div>
  );
};

export default memo(Todos); // Todo와 관련없는 App의 state(ex. count)가 변경되어도 Todos는 렌더링되지 않는다.
