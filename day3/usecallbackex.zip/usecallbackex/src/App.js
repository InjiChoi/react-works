import { useState, useCallback } from "react";
import Todos from "./Todos";

// 함수의 "결과값"을 캐시에 넣었다가 재활용 하는 것: useMemo
// 함수의 "정의"를 캐시에 넣었다가 재활용 하는 것: useCallback

function App() {
  const [count, setCount] = useState(0);
  const [todos, setTodos] = useState([]);

  const increment = () => {
    setCount(count + 1);
  };

  const addTodo = useCallback(() => {
    setTodos([...todos, "New Todo"]);
  }, [todos]);

  return (
    <div>
      <Todos todos={todos} addTodo={addTodo} />
      <hr />
      <div>
        Count: {count}
        <button onClick={increment}>+</button>
      </div>
    </div>
  );
}

export default App;
