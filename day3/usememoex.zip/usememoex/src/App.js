import { useState, useMemo } from "react";

// useMemo: 함수의 값이 변경되었을 때만 함수를 실행시키고, 변경되지 않았을 때는 이전에 실행했던 값을 재사용

const expensiveCaclulation = (num) => {
  console.log("Calculating...");
  for (let i = 0; i < 1000000000; i++) {
    num += 1;
  }
  return num;
};

function App() {
  const [count, setCount] = useState(0);
  const [todos, setTodos] = useState([]);
  const calculation = useMemo(() => expensiveCaclulation(count), [count]); // count가 바뀔 때마다 expensiveCaclulation이 실행됨

  const increment = () => {
    setCount(count + 1);
  };
  const addTodo = () => {
    setTodos([...todos, "New Todo"]);
  };

  return (
    <div>
      <div>
        <div>
          <h2>My Todos</h2>
          {todos.map((todo, index) => {
            return <p key={index}> {todo}</p>;
          })}
          <button onClick={addTodo}>Add Todo</button>
        </div>
        <hr />
        <div>
          <p>Count: {count}</p>
          <button onClick={increment}>+</button>
          <h2>Expensive Calculation</h2>
          <p>{calculation}</p> {/* count에 의존적 / todo와는 상관 없음 */}
        </div>
      </div>
    </div>
  );
}

export default App;
