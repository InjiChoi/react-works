import React, { Component } from "react";
import datatype from "prop-types";

class PropsDataType extends Component {
  render() {
    let { String, Number, Boolean, Array, Obj, Function } = this.props;
    return (
      <div>
        <p>{String}</p>
        <p>{Number}</p>
        <p>{Boolean.toString()}</p>
        <p>{Array.toString()}</p>
        <p>{JSON.stringify(Obj)}</p>
        {/* <p>{Obj.name}</p> */}
        {/* <p>{Obj.age}</p> */}
        <p>{Function}</p>
      </div>
    );
  }
}

// 데이터 타입을 지정해줌
PropsDataType.propTypes = {
  String: datatype.string,
  Number: datatype.number,
  Boolean: datatype.bool,
  Array: datatype.array,
  Obj: datatype.object,
  Function: datatype.func,
};

export default PropsDataType;
