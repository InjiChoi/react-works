import "./App.css";
import PropCom from "./PropCom";
import PersonInfo from "./PersonInfo";
import PropsDataType from "./PropsDataType";
import PropsBoolean from "./PropsBoolean";
import PropsNode from "./PropsNode";

function App() {
  return (
    <div>
      <h1>React Props Test</h1>
      <p>Props 적용하기</p>
      <PropCom props_val="THIS IS PROPCOM"></PropCom>
      <PersonInfo person={{ age: 20, name: "hong" }}></PersonInfo>
      {/* string을 제외한 javascript 변수들은 모두 중괄호로 묶어야 함 */}
      <PropsDataType
        String="react"
        Number={200}
        Boolean={1 == 1}
        Array={[1, 2, 3, 4, 5]}
        Obj={{ name: "hong", age: 20 }}
        Function={console.log("function!")}
      />
      <PropsBoolean BooleanTrueFalse /> {/* default: true */}
      <PropsBoolean BooleanTrueFalse={false} />
      <PropsNode>
        <span>node from App.js</span>
      </PropsNode>
    </div>
  );
}

export default App;
