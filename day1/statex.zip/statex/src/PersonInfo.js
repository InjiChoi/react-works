import React, { Component } from "react";

class PersonInfo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      //   age: this.props.person.age,
      //   name: this.props.person.name,
      info: { age: this.props.person.age, name: this.props.person.name },
    };
  }

  stateChange = () => {
    this.setState({ age: this.state.age + 1, name: "kim" }); // 값을 변경시킬 땐 setState를 사용해야 함
    // !!state를 직접 변경하면 안됨!!
    // this.state.age = 21;
    // this.state.name = "kim";
  };

  //   changeName = (e) => {
  //     this.setState({ name: e.target.value });
  //   };

  //   changeAge = (e) => {
  //     this.setState({ name: e.target.value });
  //   };

  changeValue = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    this.setState({ info: { ...this.state.info, [name]: value } });
    // console.log(this.state.info);
    // this.setState({ [name]: value }); // 대괄호[]: key를 변수로 사용하겠다는 의미
    // this.setState({ name: value }); => X
  };

  render() {
    return (
      <div>
        이름: <input type="text" name="name" onChange={this.changeValue} />
        &nbsp; &nbsp;
        {/* <span>이름: {this.state.name}</span> <br /> */}
        <span>이름: {this.state.info.name}</span> <br />
        나이: <input type="text" name="age" onChange={this.changeValue} />
        &nbsp; &nbsp;
        {/* <span>나이: {this.state.age}</span> <br /> */}
        <span>나이: {this.state.info.age}</span> <br />
        <button onClick={this.stateChange}>state 변경</button>
      </div>
    );
  }
}

export default PersonInfo;
