import "./App.css";
import PersonInfo from "./PersonInfo";
import FPersonInfo from "./FPersonInfo";

function App() {
  return (
    <div className="App">
      <h2>Component: PersonInfo</h2>
      <PersonInfo person={{ age: 20, name: "song" }}></PersonInfo>
      <hr />
      <h2>Component: FPersonInfo</h2>
      <FPersonInfo person={{ age: 20, name: "song" }}></FPersonInfo>
    </div>
  );
}

export default App;
