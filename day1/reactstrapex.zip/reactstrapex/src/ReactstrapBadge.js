import { Badge, Button } from "reactstrap";

function ReactstrapBadge() {
  return (
    <div>
      <h1>
        PRODUCT NAME <Badge color="secondary">hit</Badge> <br />
        <Button color="primary" outline>
          Accessor <Badge color="dark">4</Badge>
        </Button>
        <Badge color="danger" pill>
          pill
        </Badge>
        <Badge color="primary" href="https://www.google.com">
          GoLink
        </Badge>
      </h1>
    </div>
  );
}

export default ReactstrapBadge;
