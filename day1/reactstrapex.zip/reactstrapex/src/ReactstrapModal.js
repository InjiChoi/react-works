import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
import { useState } from "react";

function ReactstrapModal() {
  const [modal, setModal] = useState(false);
  const toggle = () => {
    setModal(!modal);
  };
  return (
    <>
      <Button color="danger" onClick={toggle}>
        Modal 버튼
      </Button>
      <Modal isOpen={modal} fade={true} toggle={toggle}>
        <ModalHeader toggle={toggle}>Modal title</ModalHeader>
        <ModalBody>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam
        </ModalBody>
        <ModalFooter>
          {/* TODO: 확인버튼 onClick toggle -> ?  */}
          <Button color="primary" onClick={toggle}>
            확인
          </Button>
          <Button color="secondary" onClick={toggle}>
            취소
          </Button>
        </ModalFooter>
      </Modal>
    </>
  );
}

export default ReactstrapModal;
