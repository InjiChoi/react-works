import "./App.css";
import { useRef } from "react";

function App() {
  const inputElem = useRef();
  const focusInput = () => {
    inputElem.current.focus();
  };
  return (
    <>
      <input type="text" ref={inputElem} />
      <button onClick={focusInput}>Focus Input</button>
    </>
  );
}

export default App;
