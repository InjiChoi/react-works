import Swal from "sweetalert2";

function SweetAlert2Confirm() {
  const deleteAlert = (e) => {
    Swal.fire({
      title: "삭제하시겠습니까?",
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#4B088A",
      cancelButtonColor: "#01DF01",
      confirmButtonText: "예",
      cancelButtonText: "아니오",
    }).then((result) => {
      if (result.value) {
        document.getElementById("deleteId").remove();
        Swal.fire("Deleted", "sweetalert2 삭제완료", "success");
      }
    });
  };
  return (
    <>
      <h1 id="deleteId">SweetAlert2Confirm</h1>
      <button onClick={(e) => deleteAlert()}>삭제</button>
    </>
  );
}

export default SweetAlert2Confirm;
