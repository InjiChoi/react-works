import "./App.css";
import SweetAlert2Basic from "./SweetAlert2Basic";
import SweetAlert2Position from "./SweetAlert2Position";
import SweetAlert2Confirm from "./SweetAlert2Confirm";

function App() {
  return (
    <div className="App">
      {/* <SweetAlert2Basic/> */}
      {/* <SweetAlert2Position /> */}
      <SweetAlert2Confirm/>
    </div>
  );
}

export default App;
