import { useEffect } from "react";
import Swal from "sweetalert2";

function SweetAlert2Basic() {
  useEffect(() => {
    Swal.fire("1. SweetAlert").then((result) => {
      alert("2.result.value: " + result.value);
    });
  }, []);
  return <h1>Sweetalert2</h1>;
}

export default SweetAlert2Basic;
