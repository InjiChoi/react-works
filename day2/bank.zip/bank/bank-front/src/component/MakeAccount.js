import { useState } from "react";
import axios from "axios";
import {
  Form,
  Label,
  Input,
  Button,
  Col,
  FormGroup,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
} from "reactstrap";

function MakeAccount() {
  const divStyle = {
    width: "600px",
    height: "420px",
    textAlign: "left",
    margin: "100px auto",
    border: "2px solid gray",
    padding: "30px",
    borderRadius: "20px",
  };

  const [acc, setAcc] = useState({
    id: "",
    name: "",
    balance: "",
    type: "일반계좌",
    grade: "",
  });
  const [special, setSpecial] = useState(false);
  const [modal, setModal] = useState(false);
  const [message, setMessage] = useState({ header: "", body: "" });

  const changeSpecial = (e) => {
    setSpecial(e.target.checked);
    if (e.target.checked) {
      setAcc({ ...acc, type: "특수계좌" });
    } else {
      setAcc({ ...acc, type: "일반계좌", grade: "" });
    }
  };

  const toggle = () => {
    setModal(!modal);
  };

  const change = (e) => {
    setAcc({ ...acc, [e.target.name]: e.target.value });
  };

  // 계좌번호 중복 확인
  const doubleId = (e) => {
    axios
      .post("http://localhost:3001/doubleid", { id: acc.id })
      .then((res) => {
        setMessage({
          header: "계좌번호 중복 확인",
          body: res.data.res
            ? "중복된 계좌번호입니다." // res.data.res === true
            : "사용 가능한 계좌번호입니다.", // res.data.res === false
        });
        toggle();
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // 계좌 개설
  const submit = (e) => {
    axios
      .post("http://localhost:3001/makeaccount", { acc: acc })
      .then((res) => {
        setMessage({
          header: "계좌 개설 성공",
          body: "계좌 개설에 성공했습니다.",
        });
        toggle();
      })
      .catch((err) => {
        console.log(err);
        setMessage({
          header: "계좌 개설 실패",
          body: "계좌 개설에 실패했습니다.",
        });
        toggle();
      });
  };

  return (
    <div style={divStyle}>
      <Form>
        <FormGroup row>
          <Label for="id" sm={4}>
            계좌번호
          </Label>
          <Col sm={5}>
            <Input
              type="text"
              name="id"
              id="id"
              value={acc.id}
              onChange={change}
            />
          </Col>
          <Col sm={3}>
            <Button
              color="primary"
              style={{ width: "100%" }}
              onClick={doubleId}
            >
              중복 확인
            </Button>
          </Col>
        </FormGroup>
        <FormGroup row>
          <Label for="name" sm={4}>
            이&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;름
          </Label>
          <Col sm={8}>
            <Input
              type="text"
              name="name"
              id="name"
              value={acc.name}
              onChange={change}
            />
          </Col>
        </FormGroup>
        <FormGroup row>
          <Label for="balance" sm={4}>
            잔&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;액
          </Label>
          <Col sm={8}>
            <Input
              type="text"
              name="balance"
              id="balance"
              value={acc.balance}
              onChange={change}
            />
          </Col>
        </FormGroup>
        <FormGroup row>
          <Label check sm={4}>
            <Input type="checkbox" checked={special} onChange={changeSpecial} />{" "}
            특수계좌
          </Label>
          <Col sm={8}>
            <Input
              type="select"
              name="grade"
              id="grade"
              value={acc.grade}
              style={{ color: "gray" }}
              disabled={special}
              onChange={change}
            >
              <option value={"VIP"}>VIP</option>
              <option value={"Gold"}>Gold</option>
              <option value={"Silver"}>Silver</option>
              <option value={"Normal"}>Normal</option>
            </Input>
          </Col>
        </FormGroup>
        <FormGroup row>
          <Col sm={12}>
            <Button style={{ width: "100%" }} color="primary" onClick={submit}>
              계좌 개설
            </Button>
          </Col>
        </FormGroup>
      </Form>

      <Modal isOpen={modal} fade={true} toggle={toggle}>
        <ModalHeader toggle={toggle}>{message.header}</ModalHeader>
        <ModalBody>{message.body}</ModalBody>
        <ModalFooter>
          <Button color="secondary" onClick={toggle}>
            닫기
          </Button>
        </ModalFooter>
      </Modal>
    </div>
  );
}

export default MakeAccount;
