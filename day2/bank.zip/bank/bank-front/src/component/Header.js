import { Navbar, NavbarBrand, Nav, NavItem, NavLink } from "reactstrap";
import { Link } from "react-router-dom";
import "./Header.css";

function Header() {
  return (
    <div>
      <Navbar color="light" light expand="md">
        <NavbarBrand href="/">
          <b>
            <i>KT Bank</i>
          </b>
        </NavbarBrand>
        <Nav className="ml-auto" navbar>
          <NavItem>
            {/* <NavLink href="/">계좌개설</NavLink> */}
            <Link to={"/"} className="nav-item">
              계좌개설
            </Link>
          </NavItem>
          <NavItem>
            {/* <NavLink href="/accountinfo">계좌조회</NavLink> */}
            <Link to={"/accountinfo"} className="nav-item">
              계좌조회
            </Link>
          </NavItem>
          <NavItem>
            {/* <NavLink href="/deposit">입금</NavLink> */}
            <Link to={"/deposit"} className="nav-item">
              입금
            </Link>
          </NavItem>
          <NavItem>
            {/* <NavLink href="/withdraw">출금</NavLink> */}
            <Link to={"/withdraw"} className="nav-item">
              출금
            </Link>
          </NavItem>
          <NavItem>
            {/* <NavLink href="/allaccountinfo">전체계좌조회</NavLink> */}
            <Link to={"/allaccountinfo"} className="nav-item">
              전체계좌조회
            </Link>
          </NavItem>
        </Nav>
      </Navbar>
    </div>
  );
}
export default Header;
