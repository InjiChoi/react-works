import "bootstrap/dist/css/bootstrap.min.css";
import { Routes, Route } from "react-router-dom";
import MakeAccount from "./component/MakeAccount";
import AccountInfo from "./component/AccountInfo";
import Deposit from "./component/Deposit";
import Withdraw from "./component/Withdraw";
import AllAccountInfo from "./component/AllAccountInfo";
import Header from "./component/Header";

function App() {
  return (
    <div className="App">
      <Header /> {/* 고정으로 뜨는 컴포넌트 */}
      <Routes> {/* 페이지 이동시 뜨는 컴포넌트 */}
        <Route exact path="/" element={<MakeAccount />} />
        <Route exact path="/accountinfo" element={<AccountInfo />} />
        <Route exact path="/deposit" element={<Deposit />} />
        <Route exact path="/withdraw" element={<Withdraw />} />
        <Route exact path="/allaccountinfo" element={<AllAccountInfo />} />
      </Routes>
    </div>
  );
}

export default App;
